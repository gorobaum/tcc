#ifndef CLCC_OPTIONS_HPP_INCLUDED
#define CLCC_OPTIONS_HPP_INCLUDED

//////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2009 Organic Vectory B.V.
//  Written by George van Venrooij
//
//  Distributed under the Boost Software License, Version 1.0.
//  (See accompanying file license.txt)
//////////////////////////////////////////////////////////////////////////

//! \file options.hpp
//! \brief  Defines option class that handles all command-line %options.

#include "clew.h"

#include <boost/noncopyable.hpp>
#include <boost/program_options.hpp>

//! \brief  Class that handles command-line options
class options : boost::noncopyable
{
    public:
                                        //! \brief  Constructor
                                        options(int argc, char* argv[]);
                                        //! \brief  Destructor
                                       ~options();

                                        //! \brief  Return path to OpenCL dynamic library
        const std::string&              clpath() const                          {return clpath_;}
                                        //! \brief  Returns \e true if the user requested info
        bool                            info() const                            {return info_;  }
                                        //! \brief  Returns \e true if an OpenCL source file was specified on the command line
        bool                            build() const                           {return build_; }
                                        //! \brief  Returns the selected device type
        cl_device_type                  device_type() const                     {return device_type_;}

                                        //! \brief  Returns the OpenCL source files specified on the command line
        const std::vector<std::string>& input_files() const;

    private:
        //! \brief  Short-hand variable map type
        typedef boost::program_options::variables_map   variables_map_t;
        
                            //! \brief  Variable map
        variables_map_t     variables_;
                            //! \brief  Path to OpenCL dynamic library
        std::string         clpath_;
                            //! \brief  Information request flag
        bool                info_;
                            //! \brief  Build flag
        bool                build_;
                            //! \brief  Device type to build for
        cl_device_type      device_type_;
};

#endif  //  CLCC_OPTIONS_HPP_INCLUDED
