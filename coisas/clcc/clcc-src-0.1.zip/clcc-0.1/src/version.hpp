#ifndef CLCC_VERSION_HPP_INCLUDED
#define CLCC_VERSION_HPP_INCLUDED

//////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2009 Organic Vectory B.V.
//  Written by George van Venrooij
//
//  Distributed under the Boost Software License, Version 1.0.
//  (See accompanying file license.txt)
//////////////////////////////////////////////////////////////////////////

//! \file version.hpp
//! \brief Defines the major and minor versions of CLCC

#define CLCC_VERSION_MAJOR  0   //!<    Major version number
#define CLCC_VERSION_MINOR  1   //!<    Minor version number

#endif  //  CLCC_VERSION_HPP_INCLUDED
